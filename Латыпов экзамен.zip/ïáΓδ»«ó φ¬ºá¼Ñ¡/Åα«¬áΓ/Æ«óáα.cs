﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Прокат
{
    public partial class Товар : Form
    {
        public Товар()
        {
            InitializeComponent();
        }

        private void товарBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.товарBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.ekzDataSet);

        }

        private void товарBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.товарBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.ekzDataSet);

        }

        private void товарBindingNavigatorSaveItem_Click_2(object sender, EventArgs e)
        {
            this.Validate();
            this.товарBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.ekzDataSet);

        }

        private void товарBindingNavigatorSaveItem_Click_3(object sender, EventArgs e)
        {
            this.Validate();
            this.товарBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.ekzDataSet);

        }

        private void Товар_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "ekzDataSet.Товар". При необходимости она может быть перемещена или удалена.
            this.товарTableAdapter.Fill(this.ekzDataSet.Товар);

        }

        private void кол_во_ед_в_наличииLabel_Click(object sender, EventArgs e)
        {

        }

        private void описаниеLabel_Click(object sender, EventArgs e)
        {

        }

        private void наименованиеLabel_Click(object sender, EventArgs e)
        {

        }

        private void кол_во_ед_в_наличииTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void кол_во_ед_в_прокатеLabel_Click(object sender, EventArgs e)
        {

        }

        private void кол_во_ед_в_прокатеTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void производительLabel_Click(object sender, EventArgs e)
        {

        }

        private void производительTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void адресLabel_Click(object sender, EventArgs e)
        {

        }

        private void адресTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void цена_арендыLabel_Click(object sender, EventArgs e)
        {

        }

        private void цена_арендыTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void наименованиеTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void idTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 gl = new Form1();
            gl.Show();
            Hide();
        }

        private void товарDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Авторизация lp = new Авторизация();
            lp.Show();
            Hide();
        }
    }

}
