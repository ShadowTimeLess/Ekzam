﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Прокат
{
    public partial class Авторизация : Form
    {
        public Авторизация()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string log = "User";
            string pas = "qwezxc213";
            if(textBox1.Text == log)
            {
                MessageBox.Show("Добро пожаловать на страницу заказа");

                Заказ zakaz = new Заказ();
                zakaz.Show();
                Hide();

            }
            else
            {
                MessageBox.Show("Логин или пароль не верен");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 gl = new Form1();
            gl.Show();
            Hide();
        }
    }
}
